<?php
require('connection.php');
?>
<html>
<head>
	<meta charset="utf-8">
	<title>Juan's Auto Paint</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<link rel="stylesheet" href="mystyle.css">
</head>
<body>

<nav class="my-nav">
	<a href="index">JUAN'S AUTO PAINT</a>
</nav>

<nav class="my-nav-2">
	<a class="myLink" href="newPaintJob.php">NEW PAINT JOB</a>
	<a class="myLink" href="PaintJob.php">PAINT JOBS</a>
</nav>

<div class="wrapper">
	<div class="title">
 		<h1>New Paint Job</h1>
</div>

<div class="carImage">
		<img class="images1" name="image-swap" src="image/Default Car.png"/>
		<img class="images" src="image/Shape 1.png" >
		<img class="images1" name="image-swap2" src="image/Default Car.png" >
</div>
	
<div>
<div class="function">
<form method="POST">

<div class="Description">
 		
 		<h3>Car Details</h3>	
		
		<p class="tag">Plate No. 
			<input class="textbox" type="text" name="plateNum"> 
		</p>

<p class="tag">Current Color 
	<select class="combo1" name="currentColor" onchange="setImage(this);">
	  <option value="Default" id="image/Default Car.png"> </option>
  	  <option value="Red" id="image/Red Car.png">Red</option>
      <option value="Blue" id="image/Blue Car.png">Blue</option>
      <option value="Green" id="image/Green Car.png">Green</option>
	</select>
<br />

<script>
function setImage(select){

  var image = document.getElementsByName("image-swap")[0];
  image.src = select.options[select.selectedIndex].id;
}
</script>


</p>

<p class="tag">Target Color 
	  <select class="combo2" name="TargetColor"  onchange="setImage2(this);">
 		<option value="Default" id="image/Default Car.png"> </option>
  		<option value="Red" id="image/Red Car.png">Red</option>
  		<option value="Blue" id="image/Blue Car.png">Blue</option>
  		<option value="Green" id="image/Green Car.png">Green</option>	
	  </select>

<script>
function setImage2(select){


  var image = document.getElementsByName("image-swap2")[0];
  image.src = select.options[select.selectedIndex].id;
}
</script>

	</p>
<br/>

</div>
	<button class="my-submit" type="submit" name="submit">Submit</button>
 </form>
	</div>
</div>
</body>
</html>
<?php

if(isset($_POST['submit'])){
	$plate_number = $_POST["plateNum"];
	$current_color = $_POST["currentColor"];
	$target_color = $_POST["TargetColor"];

	
	$select = "SELECT * FROM `paintjobsprogress`;";

	$check = mysqli_query($conn, $select);
	$checkrows = mysqli_num_rows($check);
			if($checkrows == 5){

		$insertQue = "INSERT INTO paintqueue(`qPlate_number`, `qCurrent_color`, `qTarget_color`) VALUES ('$plate_number', '$current_color', '$target_color');";
		mysqli_query($conn, $insertQue);
		?><script>window.location.href='PaintJob.php';</script><?php
			}else{

	$insert = "INSERT INTO paintjobsprogress(`plate_number`, `current_color`, `target_color`) VALUES ('$plate_number', '$current_color', '$target_color');";
		mysqli_query($conn, $insert);
		?><script>window.location.href='PaintJob.php';</script><?php	
			}
	
}
?>