<?php

$conn = mysqli_connect("localhost","root","","juan_auto_paint");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}else

 
?>