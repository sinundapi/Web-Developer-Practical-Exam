<?php
require('connection.php');
?>
<html>
<head>
	<meta charset="utf-8">
	<title>Juan's Auto Paint</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<link rel="stylesheet" href="mystyle.css">
</head>
<body>

<nav class="my-nav">
	<a href="index">JUAN'S AUTO PAINT</a>
</nav>

<nav class="my-nav-2">
	<a class="myLink" href="newPaintJob.php">NEW PAINT JOB</a>
	<a class="myLink" href="PaintJob.php">PAINT JOBS</a>
</nav>

<div class="wrapper">

<div class="title">
 	<h1>Paint Job</h1>
</div>

<div class="JobProgress">
	
	<p>Paint Job in Progress</p>
		<?php
		$query = "SELECT * FROM paintjobsprogress;";

 		$result = mysqli_query($conn, $query);

 		?>
 <table class="Paint">  
<thead> 
	<tr>
		<th>Plate No.</th>
		<th>Current Color</th>
		<th>Target Color</th>
		<th>Action</th>
   </tr>  
</thead>  
 <?php  
  while($row = mysqli_fetch_array($result))  
       {  
						   $plateNumber = $row['plate_number'];
						   $currentColor = $row['current_color'];
						   $TargetColor = $row['target_color'];
						   
						   echo"<tr>";
						   echo"<td>".$plateNumber."</td>";
						   echo"<td>".$currentColor."</td>";
						   echo"<td>".$TargetColor."</td>";
						   echo"<td><a class='action' href='completed.php?id=".$row['id']."'>Mark as Completed</a></td>";	   
						   echo"</tr>";
						  }
						?>
						
</table> 
</div>
<div class="ShopPerformance">
 <table>
 	<thead>
 	<tr>
 		<th class="PerformanceTable">Shop Performance</th>
 	</tr>
 </thead>
 	<?php
 	$Performance = "SELECT COUNT(`id`) AS total, SUM(case when `target_color` LIKE '%Blue%' then 1 end) as Blue, SUM(case when `target_color` LIKE '%Green%' then 1 end) as Green, SUM(case when `target_color` LIKE '%Red%' then 1 end) as Red  FROM `paintcomplete`;";
 	$result = mysqli_query($conn, $Performance);
 	while($performanceRow = mysqli_fetch_array($result)){
 		
 		$cPlateNum = $performanceRow['total'];
 		$blue = $performanceRow['Blue'];
 		$Green = $performanceRow['Green'];
 		$Red = $performanceRow['Red'];

 		echo"<td>
 		<p class='total'>Total Cars Painted:</p>
 		<p class='variables'>".$cPlateNum."</p>
 		<p class='total'>BreakDown: </p>
 		<p class='color'>Blue:</p>
 		<p class='variables'>".$blue."</p>
 		<p class='color'>Red:</p>
 		<p class='variables'>".$Red."</p>
 		<p class='color'>Green:</p>
 		<p class='variables'>".$Green."</p>
 		</td>";
 	}

 	?>
 </table>
</div>
<div class="PaintQueue">
	<p>Paint Queue</p>
		<?php
		$query = "SELECT * FROM paintjobsprogress;";
 		$result = mysqli_query($conn, $query);
 		?>
<table class="Paint"> 

<thead> 
	<tr>
		<th>Plate No.</th>
		<th>Current Color</th>
		<th>Target Color</th>
   </tr>  
</thead> 

 <?php  
 $queuepaint = "SELECT * FROM paintqueue;";
 $queue = mysqli_query($conn, $queuepaint);
  while($row = mysqli_fetch_array($queue))  
       {  
						   $QplateNumber = $row['qPlate_number'];
						   $QcurrentColor = $row['qCurrent_color'];
						   $QTargetColor = $row['qTarget_color'];
						   
						   echo"<tr>";
						   echo"<td>".$QplateNumber."</td>";
						   echo"<td>".$QcurrentColor."</td>";
						   echo"<td>".$QTargetColor."</td>";	   
						   echo"</tr>";
						  }
						?>
						
 </table> 
</div>
</body>
</html>
<?php

?>