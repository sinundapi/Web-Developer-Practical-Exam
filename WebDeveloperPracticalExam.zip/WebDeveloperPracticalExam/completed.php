<?php

require('connection.php');

$id = $_GET['id'];

$paintJob = "SELECT * FROM paintjobsprogress WHERE `id`='$id'";

$result = mysqli_query($conn, $paintJob);

while($row = mysqli_fetch_array($result)){
	
	$myID = $row['id'];
	$plateNum = $row['plate_number'];
	$currColor = $row['current_color'];
	$tarColor = $row['target_color'];


	if($id == $myID){
		$completed = "INSERT INTO paintcomplete(`plate_number`, `current_color`, `target_color`) VALUES('$plateNum', '$currColor', '$tarColor');";
		
		mysqli_query($conn, $completed);

		$delProgress = "DELETE FROM `paintjobsprogress` WHERE id = '$myID'";

		mysqli_query($conn, $delProgress);

	$paintQueue = "SELECT * FROM `paintqueue` LIMIT 1";
	$queueResult = mysqli_query($conn, $paintQueue);


	while($rowQueue = mysqli_fetch_array($queueResult)){
		
		$qID = $rowQueue['id'];
		$qPlateNum = $rowQueue['qPlate_number'];
		$qCurrentColor = $rowQueue['qCurrent_color'];
		$qTargetColor = $rowQueue['qTarget_color'];


		$insertQueue = "INSERT INTO paintjobsprogress(`plate_number`,`current_color`,`target_color`) VALUES('$qPlateNum', '$qCurrentColor', '$qTargetColor');";

		mysqli_query($conn, $insertQueue);
		$delQueue = "DELETE FROM paintqueue WHERE id = '$qID' ;";

		mysqli_query($conn, $delQueue);
		}
		?><script>window.location.href='PaintJob.php';</script><?php
	}
}

?>