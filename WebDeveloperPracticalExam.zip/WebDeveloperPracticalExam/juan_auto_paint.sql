-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2020 at 05:37 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `juan_auto_paint`
--

-- --------------------------------------------------------

--
-- Table structure for table `paintcomplete`
--

CREATE TABLE `paintcomplete` (
  `id` int(11) NOT NULL,
  `plate_number` varchar(50) NOT NULL,
  `current_color` varchar(50) NOT NULL,
  `target_color` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paintcomplete`
--

INSERT INTO `paintcomplete` (`id`, `plate_number`, `current_color`, `target_color`) VALUES
(1, '125', 'Red', 'Green'),
(2, '523', 'Red', 'Blue'),
(3, '423', 'Blue', 'Green'),
(4, '456', 'Green', 'Red');

-- --------------------------------------------------------

--
-- Table structure for table `paintjobsprogress`
--

CREATE TABLE `paintjobsprogress` (
  `id` int(11) NOT NULL,
  `plate_number` varchar(50) NOT NULL,
  `current_color` varchar(50) NOT NULL,
  `target_color` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paintjobsprogress`
--

INSERT INTO `paintjobsprogress` (`id`, `plate_number`, `current_color`, `target_color`) VALUES
(5, '21421', 'Green', 'Blue'),
(6, '523', 'Green', 'Blue');

-- --------------------------------------------------------

--
-- Table structure for table `paintqueue`
--

CREATE TABLE `paintqueue` (
  `id` int(11) NOT NULL,
  `qPlate_number` varchar(50) NOT NULL,
  `qCurrent_color` varchar(50) NOT NULL,
  `qTarget_color` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `paintcomplete`
--
ALTER TABLE `paintcomplete`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paintjobsprogress`
--
ALTER TABLE `paintjobsprogress`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paintqueue`
--
ALTER TABLE `paintqueue`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `paintcomplete`
--
ALTER TABLE `paintcomplete`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `paintjobsprogress`
--
ALTER TABLE `paintjobsprogress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `paintqueue`
--
ALTER TABLE `paintqueue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
